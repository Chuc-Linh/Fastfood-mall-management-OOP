package Interface;
public interface Itaikhoan {
    void dangnhap(String tk, String mk);
    void dangxuat();
}
