package Interface;
public interface Idanhhieu {
    String DanhHieu();
}
